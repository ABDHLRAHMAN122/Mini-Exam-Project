﻿using System;
using System.Collections.Generic;
using Exam_Project.Models;

namespace Exam_Project
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 1. Create Subject
            Subject csharpSubject = new Subject(101, "C# & .NET Programming");

            // 2. Create Students and Subscribe to Exam Event
            Student s1 = new Student(1, "Ahmed");
            Student s2 = new Student(2, "Sara");

            // 3. Create Questions and Answer Lists
            QuestionList qList = new QuestionList("Data/csharp-questions.txt");

            // Q1: True/False
            AnswerList q1Answers = new AnswerList
            {
                new Answer(1, "True"),
                new Answer(2, "False")
            };
            TrueFalseQuestion q1 = new TrueFalseQuestion("TF Question", "C# supports multiple class inheritance.", 2, q1Answers);
            qList.Add(q1);

            //choose one:
            AnswerList q2Answers = new AnswerList
            {
                new Answer(1, "struct"),
                new Answer(2, "class"),
                new Answer(3, "int")
            };
            ChooseOneQuestion q2 = new ChooseOneQuestion("Choose One", "Which keyword defines a reference type?", 3, q2Answers);
            qList.Add(q2);

            AnswerList q3Answers = new AnswerList
            {
                new Answer(1, "static constractor"),
                new Answer(2, "default constractor"),
                new Answer(3, "copy constractor"),
                new Answer(4, "override constractor")
            };
            ChooseAllQuestion q3 = new ChooseAllQuestion("ChooseAll","what is types of constractor?",5,q3Answers);
            qList.Add(q3);

            // 4. Create Practice & Final Exams
            PracticeExam practiceExam = new PracticeExam(10, 3, csharpSubject);
            practiceExam.QuestionAnswerDictionary.Add(q1, new List<int> { 2 }); // Correct: False
            practiceExam.QuestionAnswerDictionary.Add(q2, new List<int> { 2 }); // Correct: class
            practiceExam.QuestionAnswerDictionary.Add(q3, new List<int> { 1,2,3 });

            FinalExam finalExam = new FinalExam(15, 3, csharpSubject);
            finalExam.QuestionAnswerDictionary.Add(q1, new List<int> { 2 });
            finalExam.QuestionAnswerDictionary.Add(q2, new List<int> { 2 });
            finalExam.QuestionAnswerDictionary.Add(q3, new List<int> { 1, 2, 3 });

            practiceExam.ExamStarted += s1.OnExamStarted;
            practiceExam.ExamStarted += s2.OnExamStarted;

            finalExam.ExamStarted += s1.OnExamStarted;
            finalExam.ExamStarted += s2.OnExamStarted;

            // 5. User Exam Type Selection
            Console.WriteLine("=======================================");
            Console.WriteLine("   WELCOME TO EXAMINATION SYSTEM");
            Console.WriteLine("=======================================");
            Console.WriteLine("Select Exam Type:");
            Console.WriteLine("1. Practice Exam");
            Console.WriteLine("2. Final Exam");
            Console.Write("Enter Choice (1 or 2): ");

            string choice = Console.ReadLine();

            if (choice == "1")
            {
                practiceExam.StartExam(); 
                practiceExam.ShowExam();
            }
            else if (choice == "2")
            {
                finalExam.StartExam(); 
                finalExam.ShowExam();
            }
            else
            {
                Console.WriteLine("Invalid selection.");
            }
        }
    }
}
