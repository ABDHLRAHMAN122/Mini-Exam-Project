﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Exam_Project.Models;

namespace Exam_Project.Generics
{
    public class ExamContainer<T> where T : Exam
    {
        private List<T> _exams = new List<T>();

        public void AddExam(T exam) => _exams.Add(exam);
        public T GetExam(int index) => _exams[index];
    }
}
