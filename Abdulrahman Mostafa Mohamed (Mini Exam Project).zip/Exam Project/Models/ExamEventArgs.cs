﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam_Project.Models
{

    public class ExamEventArgs : EventArgs
    {
        public string SubjectName { get; set; }
        public DateTime StartTime { get; set; }

    }  

    public delegate void ExamStartedEventHandler(object sender, ExamEventArgs e);
           
}
