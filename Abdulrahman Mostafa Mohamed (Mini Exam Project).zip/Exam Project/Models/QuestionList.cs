﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam_Project.Models
{
    public class QuestionList : List<Questions> 
    {
        public string LogFilePath { get; set; }

        public QuestionList(string logFilePath)
        {
            LogFilePath = logFilePath;

            var directory = Path.GetDirectoryName(logFilePath);
            if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory);
            }
        }

        public new void Add(Questions question)
        {
            base.Add(question);

            using var writer = new StreamWriter(LogFilePath, append: true);
            writer.WriteLine($"[{DateTime.Now}] {question.head} - {question.body} (Marks: {question.marks})");
        }

    }
}
