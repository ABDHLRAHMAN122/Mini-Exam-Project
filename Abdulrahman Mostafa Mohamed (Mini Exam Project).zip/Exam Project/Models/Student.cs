﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Exam_Project.Models
{
    public class Student
    {
        public int StudentId { get; set; }
        public string Name { get; set; }

        public Student(int studentId, string name)
        {
            StudentId = studentId;
            Name = name;
        }

        public void OnExamStarted(object sender, ExamEventArgs e)
        {
          Console.WriteLine($"[Notification for Student {Name}]: Exam for subject '{e.SubjectName}' has STARTED at {e.StartTime}!");
        }
    }
}
