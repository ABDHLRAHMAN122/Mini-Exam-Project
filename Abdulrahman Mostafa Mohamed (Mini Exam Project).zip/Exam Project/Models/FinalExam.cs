﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam_Project.Models
{
    public class FinalExam : Exam
    {
        public FinalExam(int time, int numberOfQuestions, Subject subject)
           : base(time, numberOfQuestions, subject) { }

        public override void ShowExam()
        {
            Console.WriteLine($"\n--- Starting Final Exam: {Subject.SubjectName} ---");
            Console.WriteLine($"Exam Duration : {Time} Minutes");
            int TotalAnswer = 0;
            int MaxAnswer = 0;

            foreach (var item in QuestionAnswerDictionary)
            {
                Questions q = item.Key;
                List<int> correctanswer = item.Value;
                MaxAnswer += q.marks;

                Console.WriteLine($"\n{q}");
                q.Answers.DisplayAnswers();

                Console.Write("Your Answer ID(s) [separated by comma if multiple]: ");
                string input = Console.ReadLine();

                List<int> useranswer = new List<int>(); 
                foreach (var item1 in input.Split(','))
                {
                    if (int.TryParse(item1.Trim(),out int ans))
                    {
                        useranswer.Add(ans);
                    }     
                }
                useranswer.Sort();
                List<int> answer = new List<int>(correctanswer);
                answer.Sort();

                bool iscorrect = useranswer.Count == answer.Count;
                if (iscorrect) 
                {
                    for (int i = 0; i < useranswer.Count; i++)
                    {
                        if (useranswer[i] != answer[i]) { iscorrect = false; break; }
                    }                       
                }
                if (iscorrect) TotalAnswer += q.marks;

            }

            FinishExam();
            Console.WriteLine($"\nFinal Exam Finished! Your Total Score: {TotalAnswer}/{MaxAnswer}");
        }
        public override object Clone() => new FinalExam(Time, NumberOfQuestions, Subject);
    }
}
